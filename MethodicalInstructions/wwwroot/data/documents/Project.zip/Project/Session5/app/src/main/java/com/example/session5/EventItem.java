package com.example.session5;

public class EventItem {
    public int id;
    public String name;
    public String date;
    public String authorName;
    public String description;
}
